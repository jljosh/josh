### Date created
5/15/2019

### Project Title
Bikeshare 

### Description
Analyzing the bikeshare data in three US cities

### Files used
bikeshare.py

### Credits
Nope
